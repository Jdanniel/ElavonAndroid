package com.artefacto.microformas.tasks;

public class CierreTask {

}
