package com.artefacto.microformas;


public interface MFActivity
{
	public void UpdateGUI();
};
