package com.artefacto.microformas.beans;

/**
 * Created by GSI-001061_ on 30/01/2018.
 */

public class ClienteCalidadBilleteBean {

    private int idClienteCalidadBillete;
    private int idCalidadBillete;
    private int idCliente;

    public int getIdClienteCalidadBillete() {
        return idClienteCalidadBillete;
    }

    public void setIdClienteCalidadBillete(int idClienteCalidadBillete) {
        this.idClienteCalidadBillete = idClienteCalidadBillete;
    }

    public int getIdCalidadBillete() {
        return idCalidadBillete;
    }

    public void setIdCalidadBillete(int idCalidadBillete) {
        this.idCalidadBillete = idCalidadBillete;
    }

    public int getIdCliente() {
        return idCliente;
    }

    public void setIdCliente(int idCliente) {
        this.idCliente = idCliente;
    }
}
