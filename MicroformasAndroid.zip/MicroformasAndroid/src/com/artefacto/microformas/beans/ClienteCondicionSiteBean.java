package com.artefacto.microformas.beans;

/**
 * Created by GSI-001061_ on 30/01/2018.
 */

public class ClienteCondicionSiteBean {

    private int idClienteCondicionSite;
    private int idCondicionSite;
    private int idCliente;

    public int getIdClienteCondicionSite() {
        return idClienteCondicionSite;
    }

    public void setIdClienteCondicionSite(int idClienteCondicionSite) {
        this.idClienteCondicionSite = idClienteCondicionSite;
    }

    public int getIdCondicionSite() {
        return idCondicionSite;
    }

    public void setIdCondicionSite(int idCondicionSite) {
        this.idCondicionSite = idCondicionSite;
    }

    public int getIdCliente() {
        return idCliente;
    }

    public void setIdCliente(int idCliente) {
        this.idCliente = idCliente;
    }
}
