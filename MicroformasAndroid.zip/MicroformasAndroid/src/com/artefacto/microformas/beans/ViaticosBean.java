package com.artefacto.microformas.beans;

public class ViaticosBean {
	private String idViatico;
	private String descViatico;
	private int	   connStatus;
	
	public String getIdViatico() {
		return idViatico;
	}
	public void setIdViatico(String idViatico) {
		this.idViatico = idViatico;
	}
	public String getDescViatico() {
		return descViatico;
	}
	public void setDescViatico(String descViatico) {
		this.descViatico = descViatico;
	}
	public int getConnStatus() {
		return connStatus;
	}
	public void setConnStatus(int connStatus) {
		this.connStatus = connStatus;
	}
}
